import {Component} from '@angular/core';
import {FormBuilder, FormControl, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Registration Form!';

  signUpForm: FormGroup;

  username = new FormControl('', Validators.required);

  password = new FormControl('', Validators.required);


  constructor(private fb: FormBuilder) {
    this.signUpForm = this.fb.group({
      username: this.username,
      password: this.password
    });

    const usernameControl = this.signUpForm.get('username');
    usernameControl.valueChanges.forEach(
      (value: string) => console.log('change', value)
    );
  }

  public onSubmit(event: any) {
    console.log(this.signUpForm.value);
  }
}
