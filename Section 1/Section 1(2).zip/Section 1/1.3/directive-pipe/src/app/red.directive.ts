import {Directive, ElementRef, HostListener, Input} from '@angular/core';

@Directive({
  selector: '[appRed]'
})
export class RedDirective {

  @Input() fontStyle: string;

  constructor(private el: ElementRef) {
    el.nativeElement.style.color = 'red';
  }

  @HostListener('mouseenter') onMouseEnter() {
    this.el.nativeElement.style.backgroundColor = 'black';
    this.el.nativeElement.style.fontStyle = this.fontStyle;
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.el.nativeElement.style.backgroundColor = null;
    this.el.nativeElement.style.fontStyle = null;
  }
}
