
import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'format'
})
export class FormatPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let formatString = '';

    for (let i = 0; i < value.length - 1; i++) {
      formatString = formatString + value[i] + '-';
    }

    return formatString.substr(0, formatString.length - 1);
  }
}

