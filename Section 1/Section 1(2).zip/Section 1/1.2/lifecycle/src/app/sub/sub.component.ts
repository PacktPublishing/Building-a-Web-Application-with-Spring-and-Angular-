import {
  AfterContentChecked,
  AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy,
  OnInit, SimpleChanges
} from '@angular/core';

@Component({
  selector: 'app-sub',
  templateUrl: './sub.component.html',
  styleUrls: ['./sub.component.css']
})
export class SubComponent implements OnInit,
  OnChanges, DoCheck, AfterContentInit,
  AfterContentChecked, AfterViewInit,
  AfterViewChecked, OnDestroy {

  title = 'app works!';

  @Input()
  name;

  surname;

  ngOnInit() {
    console.log('ngOnInit, called after data-bound properties are init');
  }

  ngOnChanges(changes: SimpleChanges) {
    console.log('ngOnChanges, called after input properties change', changes);
  }

  ngDoCheck() {
    console.log('ngDoCheck, called when the input properties are checked');
  }

  ngAfterContentInit() {
    console.log('ngAfterContentInit, called after onInit.When all the properties are initialized');
  }

  ngAfterContentChecked() {
    console.log('ngAfterContentChecked, called every time the content get checked');
  }

  ngAfterViewInit() {
    console.log('ngAfterViewInit, called after the component view is initialized');
  }

  ngAfterViewChecked() {
    console.log('ngAfterViewChecked, called every time the view get checked');
  }

  ngOnDestroy() {
    console.log('ngOnDestroy, called before the component instance get destroyed');
  }
}
