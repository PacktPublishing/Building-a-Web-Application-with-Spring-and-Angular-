import {Component} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  isDisabled = false;

  isHidden = false;

  customClass = 'italic';

  isUpperCase = true;

  isDarkTheme = true;

  isSurnameEnabled = true;

  selectedCity;

  cityArray = ['London', 'Naples', 'New York'];

  classes = ['red', 'bold'];

  styles = {
    'font-family': 'cursive',
    'text-decoration': 'overline'
  };

  name = 'Mario';

  public click(event: any) {
    console.log('click: ' + event.srcElement.value, event);
  }

  public mouseOver(event: any) {
    console.log('mouseOver: ' + event.srcElement.value, event);
  }

  public keyUp(event: any) {
    console.log('keyUp: ' + event.srcElement.value, event);
    console.log('name: ' + this.name);
  }

  public selectCity(event: any) {
    console.log('selectCity: ' + event.srcElement.value, event);
    this.selectedCity = event.srcElement.value;
  }

  public changeHobby(event: any) {
    console.log('changeHobby: ' + event);
  }
}
